#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  spider.py
#  
#  Copyright 2017 raja <raja@raja-Inspiron-N5110>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Before running this script, you need to run sublist3r.py 
#  Run the script sublist3r.py as "python sublist3r.py -d xxx.gov.in -p 80,443 -o FileName.txt"
#  Prerequisites : 
#  sudo apt-get install libssl-dev
#  pip install pyopenssl --upgrade
#  How to crawl this spider :
#  bash$ scrapy runspider spider.py > urls.out

from scrapy.selector import HtmlXPathSelector
from scrapy.spiders import BaseSpider
from scrapy.http import Request
import sys

#DOMAIN = '2bhk.telangana.gov.in/' #sys.argv[3]
#URL = 'http://%s' % DOMAIN

with open("/home/raja/Desktop/scripts/webScraper/python/Sublist3r-master/subdomain2.txt") as f:
	
	DOMAIN = f.readlines()
	# you may also want to remove whitespace characters like `\n` at the end of each line
	DOMAIN = [x.strip() for x in DOMAIN] 
	URL = ""
#	print type(content)
#	print content
"""
Note:
We have tried to check the status code and determine if it is http or https but the time for  this check is doubling the implementation speed. 
Most of the sites have 80 port open, hence using this to increase the implementation speed.

Check ReadSubdomains.py for more clarity

for dom in content:
			DOMAIN = dom
			URL_HTTP = URL_HTTP + 'http://%s' % DOMAIN + ","
			url_http = 'http://%s' % DOMAIN
			URL_HTTPS = URL_HTTPS + 'https://%s' % DOMAIN + ","
			url_https = 'https://%s' % DOMAIN
			#print type(URL)
			CrawlCommand="scrapy runspider spider.py " + URL_HTTP + " > urls.out"
			if check_url_non_secure(url_http):
				URL = URL + url_http + ","
				print "You can use http url :  " + url_http
			else:
				if check_url_secure(url_https):
					print "Nice, you can load it with https url: " + url_https 
					URL = URL + url_https + ","
			
			#print CrawlCommand
			#os.system(CrawlCommand)
		URL_HTTP = URL_HTTP[:-1]
		URL_HTTPS = URL_HTTPS[:-1]
		URL = URL[:-1]
		#print URL
		#print type(URL)	
		URL_HTTP = URL_HTTP.split(",")
		URL_HTTPS = URL_HTTPS.split(",")
		URL = URL.split(",")
		#print type(URL)
		print URL
		""" 
	for dom in DOMAIN:
		URL = URL + 'http://%s' % dom + ","
	
	URL = URL[:-1]
	#print URL
	#print type(URL)	
	URL = URL.split(",")
	#print type(URL)
	#print URL
		
	


class MySpider(BaseSpider):
    name = DOMAIN
    allowed_domains = DOMAIN
    #print type(allowed_domains)
    start_urls = URL
    #start_urls = [
    #    URL
    #]
    
    #print type(start_urls)

    def parse(self, response):
        hxs = HtmlXPathSelector(response)
        for url in hxs.select('//a/@href').extract():
            if not ( url.startswith('http://') or url.startswith('https://') ):
                url= URL + url 
            print url
            yield Request(url, callback=self.parse)

def main(args):
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
