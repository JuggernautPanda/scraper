#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  pdfScraping.py
#  
#  Copyright 2017 raja <raja@raja-Inspiron-N5110>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  1) step 1: Upload urls
#2) step 2: Upload user specific search
#3) Output
#  https://schoolofdata.org/2013/08/16/scraping-pdfs-with-python-and-the-scraperwiki-module/

import urllib2, urlparse, lxml, os, os.path, sys, requests, re, csv, scraperwiki, json
from bs4 import BeautifulSoup
import pandas as pd
from io import BytesIO
from zipfile import ZipFile
import datetime as dt
#from urllib.request import urlopen
PAN_G = ""
Aadhar_G = ""
UserID=sys.argv[1]
today=dt.date.today()
start = dt.datetime.now()
datestamp = start.strftime("%y%m%d")

def banner():
    print("Scarping....")
"""def ReadURINames():
	with open('names.csv', 'rb') as f:
		reader = csv.reader(f)
    for row in reader:
        #print row
        uri = row
        pdflinks=get_pdf_links(uri)
        pdf = process2PDF('https://www.pdf-archive.com/2017/05/24/pancard-aadhar-card-test-data/pancard-aadhar-card-test-data.pdf')
		pdfToSoup = parse_HTML_tree(pdf)
		soupToArray = pdfToSoup.findAll('text')

#Process2excel()
#print type(soupToArray)
ContentInString = str(soupToArray)
PAN_Search(ContentInString)
Aadhar_Search(ContentInString)"""
"""for line in soupToArray:
	print line"""
	
"""for link in pdflinks:
         
        # obtain filename by splitting url and getting 
        # last string
        file_name = link.split('/')[-1]  
for FN in file_name:
	print FN"""
        
"""def PAN_custom():
	Listcsv= open('/var/www/uploads/'+UserID+'/BlackListPan.csv', 'rb')
	Redcsv = 
	Blackcsv = open('/var/www/html/outputs/'+UserID+'/BLACK/PAN_BlackListFound_'+UserID+'_'+datestamp+'.csv','a')
	reader = csv.reader(Listcsv) """

def PAN_custom(PAN):
	with open('/var/www/uploads/'+UserID+'/BlackListPan.csv', 'rb') as f:
		reader = csv.reader(f)
		#print type(reader)
		for black in reader:
			for pan in PAN:
				if pan in black:
					print "Black listed found",pan
					with open('/var/www/html/outputs/'+UserID+'/BLACK/PAN_BlackListFound_'+UserID+'_'+datestamp+'.csv','a') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(pan)
						resultFile.close()
						
def PAN_custom_json():	
						
	csvfile = open('/var/www/html/outputs/'+UserID+'/BLACK/PAN_BlackListFound_'+UserID+'_'+datestamp+'.csv', 'r')
	jsonfile = open('/var/www/html/outputs/'+UserID+'/BLACK/PAN_BlackListFound_'+UserID+'_'+datestamp+'.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print row_count
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	row_count=1;
	jsonfile.write('[')
	for row in reader:
			#print len(row)
		
		jsonfile.write('{')
		if(row_count == 1):
			jsonfile.write('"PAN":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 2
		else:
			jsonfile.write('"URL":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 1
		
	
	jsonfile.seek(-3,os.SEEK_CUR)
	jsonfile.write('\n')
	jsonfile.write(']')
	jsonfile.write('\n')
	csvfile.close()
	jsonfile.close()

def Aadhar_custom(Aadhar):
	with open('/var/www/uploads/'+UserID+'/BlackListAadhar.csv', 'rb') as f:
		reader = csv.reader(f)
		#print type(reader)
		for black in reader:
			for aadhar in Aadhar:
				if aadhar in black:
					print "Black Aadhar listed found",aadhar
					with open('/var/www/html/outputs/'+UserID+'/BLACK/Aadhar_BlackListFound_'+UserID+'_'+datestamp+'.csv','a') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(aadhar)
						resultFile.close()

def Aadhar_custom_json():
						
	csvfile = open('/var/www/html/outputs/'+UserID+'/BLACK/Aadhar_BlackListFound_'+UserID+'_'+datestamp+'.csv', 'r')
	jsonfile = open('/var/www/html/outputs/'+UserID+'/BLACK/Aadhar_BlackListFound_'+UserID+'_'+datestamp+'.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print row_count
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	row_count=1;
	jsonfile.write('[')
	for row in reader:
			#print len(row)
		
		jsonfile.write('{')
		if(row_count == 1):
			jsonfile.write('"Aadhar":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 2
		else:
			jsonfile.write('"URL":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 1
		
	
	jsonfile.seek(-3,os.SEEK_CUR)
	jsonfile.write('\n')
	jsonfile.write(']')
	jsonfile.write('\n')
	csvfile.close()
	jsonfile.close()
	
	
def PAN_Search(Scrape_string,uri):
	
	#PAN=re.findall(r'[A-Z][A-Z][A-Z]A|B|C|F|G|H|L|J|P|T|K[A-Z][0-9][0-9][0-9][0-9][A-Z]|[0-9]',Scrape_string)
	#PAN=re.findall(r'[A-Za-z]{5}',Scrape_string)
	PAN=re.findall(r'[A-Za-z]{5}\d{4}[A-Za-z]{1}',Scrape_string)
	print PAN
	#PAN=re.findall(r'[A-Z][A-Z][A-Z]A|B|C|F|G|H|L|J|P|T|K[A-Z][0-9][0-9][0-9][0-9][A-Z]',Scrape_string)
	#print "The type of PAN is %s" %(type(PAN))
	#To check if the found PAN is blackListed or not
	if not PAN:
		
		with open('/var/www/html/outputs/'+UserID+'/GREEN/PAN_GREENList_'+UserID+'_'+datestamp+'.csv','a+') as resultFile:
			wr = csv.writer(resultFile, dialect='excel')
			#wr.writerow(PAN)
			wr.writerow(uri)
			resultFile.close()
		return PAN
	
	else:	
		
		with open('/var/www/html/outputs/'+UserID+'/RED/PAN_REDList_'+UserID+'_'+datestamp+'.csv','a+') as resultFile:
			wr = csv.writer(resultFile, dialect='excel')
			wr.writerow(PAN)
			wr.writerow(uri)
			resultFile.close()
		return PAN
		
	"""if custom_search in PAN:
		print "Found custom"
		with open("/var/www/html/outputs/BLACK/PAN_BlackListFound.csv",'wb') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(pan)
						resultFile.close()"""
		
	"""with open('/var/www/uploads/BlackListPan.csv', 'rb') as f:
		reader = csv.reader(f)
		#print type(reader)
		for black in reader:
			for pan in PAN:
				if pan in black:
					print "Black listed found",pan
					with open("/var/www/html/outputs/BLACK/PAN_BlackListFound.csv",'wb') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(pan)
						resultFile.close()"""
def PAN_json(colour_code):
	
	
	
	csvfile = open('/var/www/html/outputs/'+UserID+'/'+colour_code+'/PAN_'+colour_code+'List_'+UserID+'_'+datestamp+'.csv', 'r')
	jsonfile = open('/var/www/html/outputs/'+UserID+'/'+colour_code+'/PAN_'+colour_code+'List_'+UserID+'_'+datestamp+'.json', 'w')
	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print "The type of uri now in pan search is %s" % type(uri)
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	if colour_code == "RED":
		
		row_count=1;
		jsonfile.write('[')
		jsonfile.write('{')
		for row in reader:
		#print len(row)
		
		
			if(row_count == 1):
				jsonfile.write('"pan":')
				json.dump(row,jsonfile)
				jsonfile.write(',')
				jsonfile.write("\n")
				jsonfile.write('"url":')
				#jsonfile.write('}')
				#jsonfile.write(',')
				#jsonfile.write('\n')
				row_count = 2
			else:
				#jsonfile.write('"URL":')
				json.dump(row,jsonfile)
				jsonfile.write('}')
				jsonfile.write(',')
				jsonfile.write('\n')
				jsonfile.write('{')
				row_count = 1
		
	
		jsonfile.seek(-3,os.SEEK_CUR)
		jsonfile.write('\n')
		jsonfile.write(']')
		jsonfile.write('\n')
		csvfile.close()
		jsonfile.close()
	
	elif colour_code == "GREEN":
		
		jsonfile.write('[')
		jsonfile.write('{')
		
		for row in reader:
			jsonfile.write('"url":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			
		jsonfile.seek(-1,os.SEEK_CUR)
		jsonfile.write('}')
		jsonfile.write(']')
		csvfile.close()
		jsonfile.close()
		
def Aadhar_Search(Scrape_string,uri):
	

	Aadhar=re.findall(r'\d{12}',Scrape_string)
	print Aadhar
	#print "The data type of aadhar is :"
	#print type(Aadhar)
	if not Aadhar:
		
		with open('/var/www/html/outputs/'+UserID+'/GREEN/Aadhar_GREENList_'+UserID+'_'+datestamp+'.csv','a') as resultFile:
			wr = csv.writer(resultFile, dialect='excel')
			wr.writerow(Aadhar)
			wr.writerow(uri)
		
		return Aadhar
	
	else:
		
		with open('/var/www/html/outputs/'+UserID+'/RED/Aadhar_REDList_'+UserID+'_'+datestamp+'.csv','a') as resultFile:
			wr = csv.writer(resultFile, dialect='excel')
			wr.writerow(Aadhar)
			wr.writerow(uri)
		
		return Aadhar
		
def Aadhar_json(colour_code):
		
	csvfile = open('/var/www/html/outputs/'+UserID+'/'+colour_code+'/Aadhar_'+colour_code+'List_'+UserID+'_'+datestamp+'.csv', 'r')
	jsonfile = open('/var/www/html/outputs/'+UserID+'/'+colour_code+'/Aadhar_'+colour_code+'List_'+UserID+'_'+datestamp+'.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print row_count
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	if colour_code == "RED":
		
		row_count=1;
		jsonfile.write('[')
		jsonfile.write('{')
		for row in reader:
		#print len(row)
		
		
			if(row_count == 1):
				jsonfile.write('"Aadhar":')
				json.dump(row,jsonfile)
				jsonfile.write(',')
				jsonfile.write("\n")
				jsonfile.write('"url":')
				#jsonfile.write('}')
				#jsonfile.write(',')
				#jsonfile.write('\n')
				row_count = 2
			else:
				#jsonfile.write('"URL":')
				json.dump(row,jsonfile)
				jsonfile.write('}')
				jsonfile.write(',')
				jsonfile.write('\n')
				jsonfile.write('{')
				row_count = 1
		
	
		jsonfile.seek(-3,os.SEEK_CUR)
		jsonfile.write('\n')
		jsonfile.write(']')
		jsonfile.write('\n')
		csvfile.close()
		jsonfile.close()
	
	elif colour_code == "GREEN":
		
		jsonfile.write('[')
		jsonfile.write('{')
		
		for row in reader:
			jsonfile.write('"url":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			
		jsonfile.seek(-1,os.SEEK_CUR)
		jsonfile.write('}')
		jsonfile.write(']')
		csvfile.close()
		jsonfile.close()
	
	
def Process2excel(uri):
	
	#url ="http://artconf.org/skimming/tesinf.xlsx"
	OpenURL = urllib2.urlopen(uri)
	xd = pd.ExcelFile(OpenURL)
	print xd.sheet_names
	df = xd.parse(xd.sheet_names[-1], header=None)
	df1=df.values.tolist() #Converts pandas.core.frame.DataFrame to list https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.to_string.html
	df2=df.to_string(show_dimensions=False)
	df2=df2.encode('utf-8') 
	#df1=df[0] # List to sting convertion 
	#df1 = df1.split(",")
	excel_sh=""
	print "The type of uri is %s" % type(uri)
	return df2

def Process2docx(uri):
	#file = urllib2.urlopen("http://artconf.org/skimming/zilla.docx").read()
	file = urllib2.urlopen(uri).read()
	file = BytesIO(file)
	document = ZipFile(file)
	content = document.read('word/document.xml')
	word_obj = BeautifulSoup(content.decode('utf-8'),"lxml")
	text_document = word_obj.findAll('w:t')
	doc=""
	for t in text_document:
		doc=doc+(t.text).encode('ascii','ignore')
		print ((t.text).encode('ascii','ignore'))
	
	return doc
	


def get_pdf_links(url):
     
    # create response object
    r = requests.get(url)
     
    # create beautiful-soup object
    soup = BeautifulSoup(r.content,'html5lib')
     
    # find all links on web-page
    links = soup.findAll('a')
 
    # filter the link sending with .pdf
    pdf_links = [url + link['href'] for link in links if link['href'].endswith('pdf')]
	
    return pdf_links
   

def RequestSend(url):
#Get content, regardless of whether an HTML, XML or PDF file
    pageContent = urllib2.urlopen(url)
    return pageContent

def process2PDF(LocationOfFile):
#Use this to get PDF, covert to XML
    pdfToProcess = RequestSend(LocationOfFile)
    pdfToObject = scraperwiki.pdftoxml(pdfToProcess.read())
    return pdfToObject

def parse_HTML_tree(contentToParse):
#returns a navigatibale tree, which you can iterate through
    soup = BeautifulSoup(contentToParse,"lxml")
    return soup

def process2PDFV2(LocationOfFile):
	r = requests.get(LocationOfFile)
	soup = BeautifulSoup(r.text, 'lxml')
	rows = soup.find_all('tr')[1:]
	

	for row in rows:
		cell = [i.text for i in row.find_all('td')]
		print(cell)


def ReadCrawledURLs():
	with open("./urls_test.out") as f:
		content = f.readlines()
		# you may also want to remove whitespace characters like `\n` at the end of each line
		content = [x.strip() for x in content] 
		PAN_G=[]
		Aadhar_G=[]
		#print type(content)
		#print content
		for uri in content:
			print "The type of uri is %s" %type(uri)
			if uri.endswith("pdf"):
				pdf = process2PDF(uri)
				pdfToSoup = parse_HTML_tree(pdf)
				soupToArray = pdfToSoup.findAll('text')
				ContentInString = str(soupToArray)
				uri=uri.replace(',','').split(',')
				#print "The type of uri now is %s:" %(type(uri))
				PAN_G=PAN_G+PAN_Search(ContentInString,uri)
				#print PAN
				Aadhar_G=Aadhar_G+Aadhar_Search(ContentInString,uri)
				#print Aadhar
			
			elif uri.endswith("xlsx"):
			
				ContentInString = Process2excel(uri)
				uri=uri.replace(',','').split(',')
				PAN_G=PAN_G+PAN_Search(ContentInString,uri)
				Aadhar_G=Aadhar_G+Aadhar_Search(ContentInString,uri)
				
			
			elif uri.endswith("docx"):
				#http://pythonscraping.com/pages/AWordDocument.docx
				ContentInString = Process2docx(uri)
				uri=uri.replace(',','').split(',')
				PAN_G=PAN_G+PAN_Search(ContentInString,uri)
				Aadhar_G=Aadhar_G+Aadhar_Search(ContentInString,uri)
					
	return PAN_G+Aadhar_G

def main():
	Result = ReadCrawledURLs()
	#print Result
	
	PAN_json("GREEN")
	PAN_custom(Result)
	PAN_custom_json()
	Aadhar_json("GREEN")
	Aadhar_custom(Result)
	Aadhar_custom_json()
	
	PAN_json("RED")
	PAN_custom(Result)
	PAN_custom_json()
	Aadhar_json("RED")
	Aadhar_custom(Result)
	Aadhar_custom_json()
	
		
if __name__ == "__main__":
    banner()
    res = main()

