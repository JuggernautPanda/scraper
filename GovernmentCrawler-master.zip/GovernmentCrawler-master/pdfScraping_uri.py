#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  pdfScraping.py
#  
#  Copyright 2017 raja <raja@raja-Inspiron-N5110>
#  
#  This program is not a free software; you can not redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  

#  1) step 1: Upload urls
#2) step 2: Upload user specific search
#3) Output
#  https://schoolofdata.org/2013/08/16/scraping-pdfs-with-python-and-the-scraperwiki-module/

import urllib2, urlparse, lxml, os, sys, requests, re, csv, scraperwiki, json
import pandas as pd
from io import BytesIO
from zipfile import ZipFile
from bs4 import BeautifulSoup
import argparse
#from urllib.request import urlopen


"""def ReadURINames():
	with open('names.csv', 'rb') as f:
		reader = csv.reader(f)
    for row in reader:
        #print row
        uri = row
        pdflinks=get_pdf_links(uri)
        pdf = process2PDF('https://www.pdf-archive.com/2017/05/24/pancard-aadhar-card-test-data/pancard-aadhar-card-test-data.pdf')
		pdfToSoup = parse_HTML_tree(pdf)
		soupToArray = pdfToSoup.findAll('text')

#Process2excel()
#print type(soupToArray)
ContentInString = str(soupToArray)
PAN_Search(ContentInString)
Aadhar_Search(ContentInString)"""
"""for line in soupToArray:
	print line"""
	
"""for link in pdflinks:
         
        # obtain filename by splitting url and getting 
        # last string
        file_name = link.split('/')[-1]  
for FN in file_name:
	print FN"""
G = '\033[92m'  # green
Y = '\033[93m'  # yellow
B = '\033[94m'  # blue
R = '\033[91m'  # red
W = '\033[0m'   # white
	
def banner():
    print("Scarping....")

def parser_error(errmsg):
    banner()
    print("Usage: python " + sys.argv[0] + " [Options] use -h for help")
    print(R + "Error: " + errmsg + W)
    sys.exit()

def parse_args():
    # parse the arguments
    parser = argparse.ArgumentParser(epilog='\tExample: \r\npython ' + sys.argv[0] + "-u url -p PANCARD[optional] -a AADHAR[optional]")
    parser.error = parser_error
    parser._optionals.title = "OPTIONS"
    parser.add_argument('-u', '--uri', help="URL to search data in it", required=True)
    parser.add_argument('-p', '--pan', help="If you want to custom search a PAN card number")
    parser.add_argument('-a', '--aadhar', help='If you want to custon search an Aadhar card number')
    return parser.parse_args()    
    
def PAN_custom(PAN,result,uri):
	PAN1=PAN.split(",")
	URI1=uri.split(",")
	if PAN in result:
		print "Found custom pan"
		#print "Inside PAN_custom. The type of PAN is %s and the type of uri is %s" %(type(PAN),type(uri))
		with open("/var/www/html/outputs/BLACK/PAN_BlackListFound.csv",'wb') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(PAN1)
						wr.writerow(URI1)
						resultFile.close()
						
	csvfile = open('/var/www/html/outputs/BLACK/PAN_BlackListFound.csv', 'r')
	jsonfile = open('/var/www/html/outputs/BLACK/PAN_BlackListFound.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print row_count
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	row_count=1;
	jsonfile.write('[')
	for row in reader:
			#print len(row)
		
		jsonfile.write('{')
		if(row_count == 1):
			jsonfile.write('"PAN":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 2
		else:
			jsonfile.write('"URL":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 1
		
	
	jsonfile.seek(-2,os.SEEK_CUR)
	jsonfile.write('\n')
	jsonfile.write(']')
	csvfile.close()
	jsonfile.close()

def Aadhar_custom(Aadhar, result, uri):
	Aadhar1=Aadhar.split(",")
	uri1=uri.split(",")
	if Aadhar in result:
		print "Found custom aadhar"
		with open("/var/www/html/outputs/BLACK/Aadhar_BlackListFound.csv",'wb') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(Aadhar1)
						wr.writerow(uri1)
						resultFile.close()	 
		
	csvfile = open('/var/www/html/outputs/BLACK/Aadhar_BlackListFound.csv', 'r')
	jsonfile = open('/var/www/html/outputs/BLACK/Aadhar_BlackListFound.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print row_count
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	row_count=1;
	jsonfile.write('[')
	for row in reader:
			#print len(row)
		
		jsonfile.write('{')
		if(row_count == 1):
			jsonfile.write('"Aadhar":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 2
		else:
			jsonfile.write('"URL":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 1
		
	
	jsonfile.seek(-2,os.SEEK_CUR)
	jsonfile.write('\n')
	jsonfile.write(']')   
	csvfile.close()
	jsonfile.close()
	
def PAN_Aadhar_custom(aadhar,pan,result,uri):
	if aadhar in result:
		print "Found custom"
		with open("/var/www/html/outputs/BLACK/Aadhar_BlackListFound.csv",'wb') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(aadhar)
						wr.writerow(uri)
						resultFile.close()
						
	csvfile = open('/var/www/html/outputs/BLACK/Aadhar_BlackListFound.csv', 'r')
	jsonfile = open('/var/www/html/outputs/BLACK/Aadhar_BlackListFound.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print row_count
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	row_count=1;
	jsonfile.write('[')
	for row in reader:
			#print len(row)
		
		jsonfile.write('{')
		if(row_count == 1):
			jsonfile.write('"PAN":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 2
		else:
			jsonfile.write('"URL":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 1
		
	
	jsonfile.seek(-2,os.SEEK_CUR)
	jsonfile.write('\n')
	jsonfile.write(']')
	
	if pan in result:
		print "Found custom"
		with open("/var/www/html/outputs/BLACK/PAN_BlackListFound.csv",'wb') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(pan)
						wr.writerow(uri)
						resultFile.close()
	
	csvfile = open('/var/www/html/outputs/BLACK/PAN_BlackListFound.csv', 'r')
	jsonfile = open('/var/www/html/outputs/BLACK/PAN_BlackListFound.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print row_count
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	row_count=1;
	jsonfile.write('[')
	for row in reader:
			#print len(row)
		
		jsonfile.write('{')
		if(row_count == 1):
			jsonfile.write('"PAN":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 2
		else:
			jsonfile.write('"URL":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 1
		
	
	jsonfile.seek(-2,os.SEEK_CUR)
	jsonfile.write('\n')
	jsonfile.write(']')
	csvfile.close()
	jsonfile.close()

def PAN_Search(Scrape_string,uri):
	
	#PAN=re.findall(r'[A-Z][A-Z][A-Z]A|B|C|F|G|H|L|J|P|T|K[A-Z][0-9][0-9][0-9][0-9][A-Z]|[0-9]',Scrape_string)
	#PAN=re.findall(r'[A-Za-z]{5}',Scrape_string)
	PAN=re.findall(r'[A-Za-z]{5}\d{4}[A-Za-z]{1}',Scrape_string)
	print PAN
	#PAN=re.findall(r'[A-Z][A-Z][A-Z]A|B|C|F|G|H|L|J|P|T|K[A-Z][0-9][0-9][0-9][0-9][A-Z]',Scrape_string)
	#print "The type of PAN is %s" %(type(PAN))
	#To check if the found PAN is blackListed or not
	
	with open("/var/www/html/outputs/RED/PAN_RedList.csv",'wb') as resultFile:
		wr = csv.writer(resultFile, dialect='excel')
		wr.writerow(PAN)
		wr.writerow(uri)
		resultFile.close()
	
		
	"""if custom_search in PAN:
		print "Found custom"
		with open("/var/www/html/outputs/BLACK/PAN_BlackListFound.csv",'wb') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(pan)
						resultFile.close()"""
		
	"""with open('/var/www/uploads/BlackListPan.csv', 'rb') as f:
		reader = csv.reader(f)
		#print type(reader)
		for black in reader:
			for pan in PAN:
				if pan in black:
					print "Black listed found",pan
					with open("/var/www/html/outputs/BLACK/PAN_BlackListFound.csv",'wb') as resultFile:
						wr = csv.writer(resultFile, dialect='excel')
						wr.writerow(pan)
						resultFile.close()"""
	
	csvfile = open('/var/www/html/outputs/RED/PAN_RedList.csv', 'r')
	jsonfile = open('/var/www/html/outputs/RED/PAN_RedList.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	print "The type of uri now in pan search is %s" % type(uri)
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	row_count=1;
	jsonfile.write('[')
	for row in reader:
			#print len(row)
		
		jsonfile.write('{')
		if(row_count == 1):
			jsonfile.write('"PAN":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 2
		else:
			jsonfile.write('"URL":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 1
		
	
	jsonfile.seek(-2,os.SEEK_CUR)
	jsonfile.write('\n')
	jsonfile.write(']')
	csvfile.close()
	jsonfile.close()
	
	return PAN
	
def Aadhar_Search(Scrape_string,uri):
	

	Aadhar=re.findall(r'\d{12}',Scrape_string)
	print Aadhar
	#print "The data type of aadhar is :"
	#print type(Aadhar)
	with open("/var/www/html/outputs/RED/Aadhar_RedList.csv",'wb') as resultFile:
		wr = csv.writer(resultFile, dialect='excel')
		wr.writerow(Aadhar)
		wr.writerow(uri)
		
	csvfile = open('/var/www/html/outputs/RED/Aadhar_RedList.csv', 'r')
	jsonfile = open('/var/www/html/outputs/RED/Aadhar_RedList.json', 'w')

	reader = csv.reader(csvfile, delimiter=' ',quotechar='|')
	#data = list(reader)
	#row_count = len(data)
	#print row_count
	#print type(row_count)
	#print len(reader)
	#print type(reader)
	row_count=1;
	jsonfile.write('[')
	for row in reader:
			#print len(row)
		
		jsonfile.write('{')
		if(row_count == 1):
			jsonfile.write('"aadhars":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 2
		else:
			jsonfile.write('"URL":')
			json.dump(row,jsonfile)
			jsonfile.write('}')
			jsonfile.write(',')
			jsonfile.write('\n')
			row_count = 1
		
	
	jsonfile.seek(-2,os.SEEK_CUR)
	jsonfile.write('\n')
	jsonfile.write(']')
	csvfile.close()
	jsonfile.close()
	
	return Aadhar
	
def Process2excel(uri):
	
	#url ="http://artconf.org/skimming/tesinf.xlsx"
	OpenURL = urllib2.urlopen(uri)
	xd = pd.ExcelFile(OpenURL)
	print xd.sheet_names
	df = xd.parse(xd.sheet_names[-1], header=None)
	df1=df.values.tolist() #Converts pandas.core.frame.DataFrame to list https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.to_string.html
	df2=df.to_string(show_dimensions=False)
	df2=df2.encode('utf-8') 
	#df1=df[0] # List to sting convertion 
	#df1 = df1.split(",")
	print "The type of uri is %s" % type(uri)
	return df2

def Process2docx(uri):
	#file = urllib2.urlopen("http://artconf.org/skimming/zilla.docx").read()
	file = urllib2.urlopen(uri).read()
	file = BytesIO(file)
	document = ZipFile(file)
	content = document.read('word/document.xml')
	word_obj = BeautifulSoup(content.decode('utf-8'),"lxml")
	text_document = word_obj.findAll('w:t')
	doc=""
	for t in text_document:
		doc=doc+(t.text).encode('ascii','ignore')
		print ((t.text).encode('ascii','ignore'))
	
	return doc

def get_pdf_links(url):
     
    # create response object
    r = requests.get(url)
     
    # create beautiful-soup object
    soup = BeautifulSoup(r.content,'html5lib')
     
    # find all links on web-page
    links = soup.findAll('a')
 
    # filter the link sending with .pdf
    pdf_links = [url + link['href'] for link in links if link['href'].endswith('pdf')]
	
    return pdf_links
   

def RequestSend(url):
#Get content, regardless of whether an HTML, XML or PDF file
    pageContent = urllib2.urlopen(url)
    return pageContent

def process2PDF(LocationOfFile):
#Use this to get PDF, covert to XML
    pdfToProcess = RequestSend(LocationOfFile)
    pdfToObject = scraperwiki.pdftoxml(pdfToProcess.read())
    return pdfToObject

def parse_HTML_tree(contentToParse):
#returns a navigatibale tree, which you can iterate through
    soup = BeautifulSoup(contentToParse,"lxml")
    return soup

def process2PDFV2(LocationOfFile):
	r = requests.get(LocationOfFile)
	soup = BeautifulSoup(r.text, 'lxml')
	rows = soup.find_all('tr')[1:]
	

	for row in rows:
		cell = [i.text for i in row.find_all('td')]
		print(cell)


def ReadCrawledURLs(uri):
	#with open("./urls.out") as f:
		#content = f.readlines()
		# you may also want to remove whitespace characters like `\n` at the end of each line
		#content = [x.strip() for x in content] 

		#print type(content)
		#print content
		#uri=str(content)
		#uri="https://www.pdf-archive.com/2017/05/24/pancard-aadhar-card-test-data/pancard-aadhar-card-test-data.pdf"
	if uri.endswith("pdf"):
			
		pdf = process2PDF(uri)
		pdfToSoup = parse_HTML_tree(pdf)
		soupToArray = pdfToSoup.findAll('text')
		ContentInString = str(soupToArray)
		uri=uri.replace(',','').split(',')
		#print "The type of uri now is %s:" %(type(uri))
		PAN=PAN_Search(ContentInString,uri)
		#print PAN
		Aadhar=Aadhar_Search(ContentInString,uri)
		#print Aadhar
		return PAN+Aadhar
			
	elif uri.endswith("xlsx"):
			
		ContentInString = Process2excel(uri)
		uri=uri.replace(',','').split(',')
		PAN=PAN_Search(ContentInString,uri)
		Aadhar=Aadhar_Search(ContentInString,uri)
		return PAN+Aadhar
			
	elif uri.endswith("docx"):
		#http://pythonscraping.com/pages/AWordDocument.docx
		ContentInString = Process2docx(uri)
		uri=uri.replace(',','').split(',')
		PAN=PAN_Search(ContentInString,uri)
		Aadhar=Aadhar_Search(ContentInString,uri)
		return PAN+Aadhar
		
			
def main(uri, custom_pan, custom_aadhar):
	Result = ReadCrawledURLs(uri)
	print Result
	if (custom_aadhar and custom_pan):
		PAN_Aadhar_custom(custom_aadhar,custom_pan, Result, uri)
	elif (custom_aadhar):
		Aadhar_custom(custom_aadhar, Result,uri)
	elif (custom_pan):
		PAN_custom(custom_pan, Result ,uri)
		

if __name__ == "__main__":
    args = parse_args()
    uri = args.uri
    custom_pan=args.pan
    custom_aadhar= args.aadhar
    banner()
    res = main(uri, custom_pan, custom_aadhar)
			

		
#uri="http://www-personal.umich.edu/~csev/books/py4inf/media/"
#pdflinks=get_pdf_links(uri)


#pdf = process2PDF('https://www.pdf-archive.com/2017/05/24/pancard-aadhar-card-test-data/pancard-aadhar-card-test-data.pdf')
#pdfToSoup = parse_HTML_tree(pdf)
#soupToArray = pdfToSoup.findAll('text')


#Process2excel()
#print type(soupToArray)
#ContentInString = str(soupToArray)
#PAN_Search(ContentInString,uri)
#Aadhar_Search(ContentInString,uri)
"""for line in soupToArray:
	print line"""
	
"""for link in pdflinks:
         
        # obtain filename by splitting url and getting 
        # last string
        file_name = link.split('/')[-1]  
for FN in file_name:
	print FN"""

