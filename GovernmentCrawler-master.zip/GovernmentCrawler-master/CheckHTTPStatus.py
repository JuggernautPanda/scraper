#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  CheckHTTPStatus.py
#  
#  Copyright 2017 raja <raja@raja-Inspiron-N5110>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  
import scraperwiki, urllib2, urlparse, lxml, os, sys, requests, re, csv
from bs4 import BeautifulSoup
import pandas as pd
from io import BytesIO
from zipfile import ZipFile
import os
from urlparse import urlparse
import httplib, sys

def get_pdf_links(url):
     
    # create response object
    r = requests.get(url)
     
    # create beautiful-soup object
    soup = BeautifulSoup(re.text, "html.parser")
    #soup = BeautifulSoup(r.content,'html5lib')
     
    # find all links on web-page
    links = soup.findAll('a')
    #print links
 
    # filter the link sending with .pdf
	pdf_links = [url + link['href'] for link in links if link['href'].endswith('pdf')]
	
	return pdf_links
	

def check_url_secure(url):
	try:
		url = urlparse(url)
		conn = httplib.HTTPSConnection(url.netloc)   
		conn.request("HEAD", url.path)
		code = conn.getresponse().status
		return code
		
	except StandardError:
		return None

def main(args):
    print check_url_secure("https://www.ultimatix.net")
    get_pdf_links("http://2bhk.telangana.gov.in")

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
