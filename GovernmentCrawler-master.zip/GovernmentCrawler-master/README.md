# GovernmentCrawler
Python crawler Code
Authorized access only
