#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  FirstJob.py
#  
#  Copyright 2017 raja <raja@raja-Inspiron-N5110>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
# 

import os,sublist3r,os.path, sys, csv, datetime as dt

def Listing():
	print len([name for name in os.listdir('.') if os.path.isfile(name)])

	# path joining version for other paths
	DIR = '/tmp'
	print len([name for name in os.listdir(DIR) if os.path.isfile(os.path.join(DIR, name))])

UserID=sys.argv[1]
#print type(UserID) # It is a string
with open('/var/www/uploads/'+UserID+'/PwC_PrivSearch.csv', 'rb') as f:
	
	reader = csv.reader(f, delimiter=' ',quotechar='|')
	
	for url in reader:
		
	
		#SubListCommand="python sublist3r.main(-d" + url + "-p 80,443 -o /var/www/IO/UserID/SubDomain"+ Num +".txt")
		#print url[0]
		#print type(url[0])
		today=dt.date.today()
		start = dt.datetime.now()
		datestamp = start.strftime("%y%m%d")
		#print type(timestamp)
		#print timestamp
		FileName = "/home/raja/Desktop/scripts/webScraper/python/"+UserID+"/SubDomainList_"+UserID+"_"+datestamp+".txt"
		#print FileName
		#domain, threads, savefile, ports, silent, verbose, enable_bruteforce, engine
		#dom="reteiot.com"
		sublist3r.main(url[0], "30", FileName, "80,443", False, False, False, None)

def main(args):
    return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
